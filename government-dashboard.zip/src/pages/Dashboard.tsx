export default function Dashboard() {
  return (
    <div className="min-h-screen flex items-center justify-center text-white">
      <h2 className="text-2xl font-bold">Dashboard Loaded</h2>
    </div>
  );
}
