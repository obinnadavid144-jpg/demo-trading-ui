import { useEffect, useState } from "react";
import Loader from "./components/Loader";
import Dashboard from "./pages/Dashboard";

export default function App() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 4000);
    return () => clearTimeout(t);
  }, []);

  return loading ? <Loader /> : <Dashboard />;
}
