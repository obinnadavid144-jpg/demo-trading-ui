export default function Loader() {
  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-black text-white">
      <h1 className="text-4xl font-extrabold tracking-widest mb-6">
        GOVERNMENT
      </h1>

      <div className="flex gap-3">
        <span className="w-4 h-4 bg-red-500 rounded-full animate-bounce"></span>
        <span className="w-4 h-4 bg-green-500 rounded-full animate-bounce [animation-delay:150ms]"></span>
        <span className="w-4 h-4 bg-blue-500 rounded-full animate-bounce [animation-delay:300ms]"></span>
      </div>

      <p className="mt-6 text-gray-400 text-sm tracking-wide">
        Secure system initializing…
      </p>
    </div>
  );
}
